module.exports = {
    mongoURI: 'mongodb+srv://admin:hzkXscYQK4PxNW16@mern.9vssy.mongodb.net/test?retryWrites=true&w=majority',
    secretOrKey: 'd&gs?vGWG97!0L0SIrBY#KJvGfl,FU'
}